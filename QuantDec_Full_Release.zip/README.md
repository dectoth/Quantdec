
# QuantDec

QuantDec is a web-based trading simulator for students and aspiring investment bankers.  
Built using Python and Streamlit. Includes live market data, strategy builder, and risk reporting.

## Try it Live
Coming soon at [quantdec.streamlit.app](https://quantdec.streamlit.app)
