
import streamlit as st

st.set_page_config(page_title="QuantDec", layout="wide")
st.title("📊 QuantDec: Trading Simulator for Students")

st.markdown("""
Welcome to **QuantDec**, a realistic and educational trading simulator built for aspiring investment bankers and finance students.

🚀 Use the sidebar to navigate through:

- **Live Market Simulations**
- **Quantitative Strategy Builder**
- **Risk Management Dashboards**
- **Portfolio Performance Reports**

💡 Ideal for CVs, LinkedIn, and real-world interview preparation.
""")

st.success("You're viewing the beta version of QuantDec.")
